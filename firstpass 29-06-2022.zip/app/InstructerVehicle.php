<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InstructerVehicle extends Model
{
    protected $guarded = ['id'];
}
